from django.apps import AppConfig


class DjangoApp1Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'django_app1'
